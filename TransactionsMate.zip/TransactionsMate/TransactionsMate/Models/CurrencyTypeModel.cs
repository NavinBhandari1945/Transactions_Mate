﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TransactionsMate.Models
{
    public class CurrencyTypeModel
    {
        //USD NRS INR GBP
        public string CurrencyType { get; set; }

    }
}
